CREATE TABLE IF NOT EXISTS indicators (
    country_code TEXT NOT NULL,
    country_name TEXT NOT NULL,
    year INTEGER NOT NULL,
    population REAL,
    gdp_per_capita REAL,
    PRIMARY KEY (country_code, year)
);
