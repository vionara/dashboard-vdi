"""Mengambil indikator World Bank dan menyimpannya ke SQLite."""
import os
import time
import requests
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

load_dotenv()
DB_PATH = os.getenv("SQLITE_PATH", "database/world_data.db")
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
engine = create_engine(f"sqlite:///{DB_PATH}")

INDICATORS = {
    "population": "SP.POP.TOTL",
    "gdp_per_capita": "NY.GDP.PCAP.CD",
}
COUNTRIES = ["IDN", "MYS", "SGP", "THA", "PHL", "VNM", "JPN", "KOR", "CHN", "IND", "USA", "GBR", "AUS"]
START_YEAR, END_YEAR = 2010, 2023

def fetch_indicator(country_code, indicator_code):
    url = f"https://api.worldbank.org/v2/country/{country_code}/indicator/{indicator_code}"
    params = {"format": "json", "per_page": 100, "date": f"{START_YEAR}:{END_YEAR}"}
    response = requests.get(url, params=params, timeout=30)
    response.raise_for_status()
    payload = response.json()
    if len(payload) < 2 or payload[1] is None:
        return []
    return payload[1]

def main():
    records = {}
    for code in COUNTRIES:
        print(f"Mengambil data {code}...")
        for name, indicator in INDICATORS.items():
            for item in fetch_indicator(code, indicator):
                year = int(item["date"])
                key = (code, year)
                records.setdefault(key, {
                    "country_code": code,
                    "country_name": item["country"]["value"],
                    "year": year,
                })
                records[key][name] = item["value"]
            time.sleep(0.15)

    df = pd.DataFrame(records.values())
    df["population"] = pd.to_numeric(df.get("population"), errors="coerce")
    df["gdp_per_capita"] = pd.to_numeric(df.get("gdp_per_capita"), errors="coerce")
    df = df.dropna(subset=["population"])
    with engine.begin() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS indicators (
                country_code TEXT NOT NULL,
                country_name TEXT NOT NULL,
                year INTEGER NOT NULL,
                population REAL,
                gdp_per_capita REAL,
                PRIMARY KEY (country_code, year)
            )
        """))
        conn.execute(text("DELETE FROM indicators"))
    df.to_sql("indicators", engine, if_exists="append", index=False)
    print(f"Selesai. {len(df)} baris disimpan ke {DB_PATH}")

if __name__ == "__main__":
    main()
